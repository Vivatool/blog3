<?php

class AddCommentPage extends BasePage
{
    private $postModel;
    private $errors = [];

    public function __construct()
    {
        $this->postModel = new Comment();
    }

    protected function get()
    {
        require_once './view/comment_page.php';
    }

    protected function post() {
            $id = $this->postModel->addPost($this->postData['title'],
            $this->postData['body'],
            $this->postData['author']);

        $this->redirect('/post&id=' . $id);
    }
}